Rails.application.routes.draw do
  
mount ActionCable.server => '/cable'

  post "users/:id/update" => "users#update"
  
  get "users/:id" => "users#show"
  
  get "users/:id/edit" => "users#edit"
  get "login" => "users#login_form" 
  post "login" => "users#login"
  
  post "logout" => "users#logout"
  
  post "users/create" => "users#create"
  
  get "signup" => "users#new"
  
  get "/" => "home#top"
  get "/about" => "home#about"
  
  get "/rooms/show" => "rooms#show"
  
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
 
end
